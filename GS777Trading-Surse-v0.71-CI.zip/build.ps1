$ErrorActionPreference='Stop'
$sdk=$env:ANDROID_HOME
if(-not $sdk){$sdk=$env:ANDROID_SDK_ROOT}
if(-not $sdk){$sdk=Join-Path $env:LOCALAPPDATA 'Android\Sdk'}
$tools=Join-Path $sdk 'build-tools\35.0.1'
$android=Join-Path $sdk 'platforms\android-35\android.jar'
$jdk=if($env:JAVA_HOME){Join-Path $env:JAVA_HOME 'bin'}else{(Get-Command javac.exe -ErrorAction Stop).Source | Split-Path}
if(-not (Test-Path $android)){throw "Android SDK Platform 35 lipseste: $android"}
if(-not (Test-Path (Join-Path $tools 'aapt2.exe'))){throw "Android Build Tools 35.0.1 lipsesc: $tools"}

$project=$PSScriptRoot
$build=Join-Path $project 'build'
New-Item -ItemType Directory -Force (Join-Path $build 'classes'),(Join-Path $build 'dex'),(Join-Path $build 'tmp') | Out-Null
$env:TEMP=Join-Path $build 'tmp'
$env:TMP=$env:TEMP
Get-ChildItem (Join-Path $build 'classes') -Filter '*.class' -Recurse | Remove-Item -Force
$java=Get-ChildItem (Join-Path $project 'src') -Filter '*.java' -Recurse | Select-Object -ExpandProperty FullName
& (Join-Path $jdk 'javac.exe') -encoding UTF-8 -source 8 -target 8 -cp $android -d (Join-Path $build 'classes') $java
if($LASTEXITCODE){throw 'Compilarea Java a eșuat'}
& (Join-Path $jdk 'jar.exe') cf (Join-Path $build 'classes.jar') -C (Join-Path $build 'classes') .
if($LASTEXITCODE){throw 'Arhivarea Java a eșuat'}
& (Join-Path $tools 'd8.bat') --min-api 26 --lib $android --output (Join-Path $build 'dex') (Join-Path $build 'classes.jar')
if($LASTEXITCODE){throw 'Generarea DEX a eșuat'}
New-Item -ItemType Directory -Force (Join-Path $build 'resources') | Out-Null
& (Join-Path $tools 'aapt2.exe') compile --dir (Join-Path $project 'res') -o (Join-Path $build 'resources')
if($LASTEXITCODE){throw 'Compilarea resurselor a esuat'}
$res=Get-ChildItem (Join-Path $build 'resources') -Filter '*.flat' | Select-Object -ExpandProperty FullName
& (Join-Path $tools 'aapt2.exe') link -o (Join-Path $build 'unsigned.apk') --manifest (Join-Path $project 'AndroidManifest.xml') -I $android --min-sdk-version 26 --target-sdk-version 33 --version-code 70 --version-name 0.70.0 --auto-add-overlay ($res | ForEach-Object { '-R'; $_ })
if($LASTEXITCODE){throw 'Generarea AndroidManifest a eșuat'}
Push-Location (Join-Path $build 'dex')
try { & (Join-Path $jdk 'jar.exe') uf (Join-Path $build 'unsigned.apk') classes.dex; if($LASTEXITCODE){throw 'Adăugarea DEX a eșuat'} } finally { Pop-Location }
& (Join-Path $tools 'zipalign.exe') -f -p 4 (Join-Path $build 'unsigned.apk') (Join-Path $build 'aligned.apk')
if($LASTEXITCODE){throw 'Alinierea APK a eșuat'}
$key=Join-Path $project 'gs777-debug.keystore'
if(!(Test-Path $key)) {
 & (Join-Path $jdk 'keytool.exe') -genkeypair -noprompt -alias gs777-debug -keyalg RSA -keysize 2048 -validity 3650 -keystore $key -storepass android -keypass android -dname 'CN=GS777 Trading Demo, O=GS777, C=RO'
 if($LASTEXITCODE){throw 'Generarea semnăturii a eșuat'}
}
$out=Join-Path $project 'GS777Trading-Help-v0.70.apk'
& (Join-Path $tools 'apksigner.bat') sign --ks $key --ks-key-alias gs777-debug --ks-pass pass:android --key-pass pass:android --out $out (Join-Path $build 'aligned.apk')
if($LASTEXITCODE){throw 'Semnarea APK a eșuat'}
& (Join-Path $tools 'apksigner.bat') verify --verbose --print-certs $out
if($LASTEXITCODE){throw 'Verificarea APK a eșuat'}
Write-Host "APK: $out"








